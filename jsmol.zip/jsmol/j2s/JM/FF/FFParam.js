Clazz.declarePackage ("JM.FF");
var c$ = Clazz.decorateAsClass (function () {
this.iVal = null;
this.dVal = null;
this.sVal = null;
Clazz.instantialize (this, arguments);
}, JM.FF, "FFParam");
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
