Clazz.declarePackage ("JSV.api");
Clazz.load (["JSV.api.JSVViewPanel"], "JSV.api.JSVPanel", null, function () {
Clazz.declareInterface (JSV.api, "JSVPanel", JSV.api.JSVViewPanel);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
