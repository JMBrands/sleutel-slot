Clazz.declarePackage ("JSV.api.js");
Clazz.load (["javajs.api.js.JSAppletObject"], "JSV.api.js.JSVAppletObject", null, function () {
Clazz.declareInterface (JSV.api.js, "JSVAppletObject", javajs.api.js.JSAppletObject);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
