Clazz.declarePackage ("JSV.api.js");
Clazz.load (["javajs.api.js.J2SObjectInterface"], "JSV.api.js.JSVToJSmolInterface", null, function () {
Clazz.declareInterface (JSV.api.js, "JSVToJSmolInterface", javajs.api.js.J2SObjectInterface);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
