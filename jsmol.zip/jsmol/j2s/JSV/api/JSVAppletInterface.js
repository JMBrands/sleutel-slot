Clazz.declarePackage ("JSV.api");
Clazz.declareInterface (JSV.api, "JSVAppletInterface");
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
