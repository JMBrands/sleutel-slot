Clazz.declarePackage ("JSV.api");
Clazz.load (["JSV.api.JSVViewPanel"], "JSV.api.JSVMainPanel", null, function () {
Clazz.declareInterface (JSV.api, "JSVMainPanel", JSV.api.JSVViewPanel);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
