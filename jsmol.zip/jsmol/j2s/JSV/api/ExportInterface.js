Clazz.declarePackage ("JSV.api");
Clazz.load (["JSV.api.JSVExporter"], "JSV.api.ExportInterface", null, function () {
Clazz.declareInterface (JSV.api, "ExportInterface", JSV.api.JSVExporter);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
