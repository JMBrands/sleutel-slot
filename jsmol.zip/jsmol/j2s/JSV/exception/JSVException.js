Clazz.declarePackage ("JSV.exception");
Clazz.load (["java.lang.Exception"], "JSV.exception.JSVException", null, function () {
var c$ = Clazz.declareType (JSV.exception, "JSVException", Exception);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
