Clazz.declarePackage ("JS");
Clazz.load (["JS.TableColumn"], "JS.AbstractTableModel", null, function () {
Clazz.declareInterface (JS, "AbstractTableModel", JS.TableColumn);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
