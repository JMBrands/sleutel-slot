Clazz.declarePackage ("JS");
Clazz.load (["JS.JComponent"], "JS.JComponentImp", null, function () {
var c$ = Clazz.declareType (JS, "JComponentImp", JS.JComponent);
Clazz.overrideMethod (c$, "toHTML", 
function () {
return null;
});
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
