Clazz.declarePackage ("JS");
Clazz.load (["JS.LayoutManager"], "JS.GridBagLayout", null, function () {
var c$ = Clazz.declareType (JS, "GridBagLayout", JS.LayoutManager);
});
;//5.0.1-v2 Sat Nov 25 17:51:22 CST 2023
